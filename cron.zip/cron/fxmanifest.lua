fx_version 'adamant'

game 'gta5'
author 'ESX-Framework'
description 'cron'
lua54 'yes'
version '1.10.1'

server_script 'server/main.lua'
